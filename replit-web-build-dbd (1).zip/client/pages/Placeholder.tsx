import { Link, useLocation } from "react-router-dom";
import { SiteLayout } from "@/components/SiteLayout";

const pageTitles: Record<string, string> = { "/services": "Timing Services", "/about": "About Us", "/contact": "Contact Us" };

export default function Placeholder() {
  const location = useLocation();
  const title = pageTitles[location.pathname] ?? "Page";
  return <SiteLayout><section className="flex min-h-[55vh] items-center bg-secondary"><div className="container px-6 py-24 text-center md:px-12"><p className="mb-4 font-display text-sm font-bold uppercase tracking-[0.2em] text-accent">Precision Timing Co.</p><h1 className="mb-6 font-display text-5xl font-bold uppercase text-primary md:text-7xl">{title}</h1><p className="mx-auto mb-10 max-w-xl text-lg leading-relaxed text-muted-foreground">This page is ready for its dedicated content. Continue building with us to bring this part of the Precision Timing experience to life.</p><Link to="/" className="inline-flex bg-primary px-8 py-4 font-display font-bold uppercase tracking-wide text-white transition-colors hover:bg-accent">Back to Home</Link></div></section></SiteLayout>;
}
