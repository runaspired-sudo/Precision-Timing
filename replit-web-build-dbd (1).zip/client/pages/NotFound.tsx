import { Link } from "react-router-dom";
import { SiteLayout } from "@/components/SiteLayout";

export default function NotFound() {
  return <SiteLayout><section className="flex min-h-[55vh] items-center bg-secondary"><div className="container px-6 py-24 text-center md:px-12"><p className="mb-4 font-display text-sm font-bold uppercase tracking-[0.2em] text-accent">404</p><h1 className="mb-6 font-display text-5xl font-bold uppercase text-primary md:text-7xl">Finish Line Not Found</h1><p className="mx-auto mb-10 max-w-xl text-lg text-muted-foreground">The page you requested is not part of this course.</p><Link to="/" className="inline-flex bg-primary px-8 py-4 font-display font-bold uppercase tracking-wide text-white transition-colors hover:bg-accent">Return Home</Link></div></section></SiteLayout>;
}
