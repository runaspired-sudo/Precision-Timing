import { ArrowRight, Medal, MonitorCheck, RadioTower, Target, Timer, Trophy, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { SiteLayout } from "@/components/SiteLayout";

const features = [
  { icon: Target, title: "99.9% Read Rates", description: "Our dual-frequency RFID mat systems ensure unparalleled accuracy, capturing timing chips even in the densest packs of runners." },
  { icon: MonitorCheck, title: "Live Online Results", description: "Spectators and athletes get instant gratification. Results stream to mobile-friendly sites in real-time as runners cross the mats." },
  { icon: Users, title: "White-Glove Support", description: "From initial registration setup to post-race reporting, you get a dedicated timing director who knows your event inside and out." },
];

const services = [
  { icon: RadioTower, title: "Chip Timing", description: "UHF RFID systems for foolproof read reliability." },
  { icon: MonitorCheck, title: "Live Results", description: "Mobile-optimized instantaneous finish times." },
  { icon: Timer, title: "Race Clocks", description: "Double-sided LED clocks and finish line structures." },
  { icon: Medal, title: "Custom Bibs", description: "Pre-chipped, branded bib printing and fulfillment." },
];

export default function Index() {
  return <SiteLayout>
    <section className="relative flex min-h-[85vh] items-center overflow-hidden bg-primary">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_50%,rgba(205,14,17,0.2),transparent_52%)]" />
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1541252876100-34ee6cb51b4e?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-15" />
      <div className="container relative z-10 px-6 py-24 md:px-12">
        <div className="max-w-3xl">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-3 py-1"><span className="h-2 w-2 animate-pulse rounded-full bg-accent" /><span className="font-display text-sm font-bold uppercase tracking-widest text-accent">Trusted by 500+ Races</span></div>
          <h1 className="mb-6 font-display text-5xl font-bold leading-[1.05] text-white md:text-7xl">WE TIME IT.<br /><span className="bg-gradient-to-r from-white to-white/50 bg-clip-text text-transparent">YOU OWN THE FINISH LINE.</span></h1>
          <p className="mb-10 max-w-2xl text-lg leading-relaxed text-white/80 md:text-xl">Precision RFID chip timing, instant live results, and bulletproof reliability for running, cycling, and multi-sport endurance events. When every second matters, trust the experts.</p>
          <div className="flex flex-col gap-4 sm:flex-row"><Link to="/contact" className="group inline-flex h-14 items-center justify-center rounded-md bg-accent px-10 font-display text-base font-bold uppercase tracking-wide text-white transition-colors hover:bg-accent/90">Get a Quote <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" /></Link><Link to="/services" className="inline-flex h-14 items-center justify-center rounded-md border-2 border-white/20 px-10 font-display text-base font-bold uppercase tracking-wide text-white transition-colors hover:bg-white hover:text-primary">Explore Services</Link></div>
        </div>
      </div>
    </section>

    <section className="bg-white py-24"><div className="container px-6 md:px-12"><div className="mx-auto mb-16 max-w-3xl text-center"><h2 className="mb-6 font-display text-3xl font-bold text-primary md:text-5xl">WHY DIRECTORS CHOOSE US</h2><p className="text-lg text-muted-foreground">We bring more than just equipment to your race. We bring a proven system designed for absolute accuracy and zero stress on race day.</p></div><div className="grid gap-8 md:grid-cols-3">{features.map(({ icon: Icon, title, description }) => <article key={title} className="border border-border bg-secondary/50 p-8"><div className="mb-6 flex h-14 w-14 items-center justify-center bg-white text-accent shadow-sm"><Icon className="h-7 w-7" /></div><h3 className="mb-4 font-display text-xl font-bold">{title}</h3><p className="leading-relaxed text-muted-foreground">{description}</p></article>)}</div></div></section>

    <section className="border-t-8 border-accent bg-primary py-24 text-white"><div className="container px-6 md:px-12"><div className="mb-16 flex flex-col items-start justify-between gap-6 md:flex-row md:items-end"><div className="max-w-2xl"><h2 className="mb-6 font-display text-3xl font-bold md:text-5xl">END-TO-END TIMING SOLUTIONS</h2><p className="text-lg text-white/70">Everything you need to execute a flawless event, from small 5Ks to massive city marathons.</p></div><Link to="/services" className="inline-flex h-12 items-center justify-center border-2 border-white/20 px-6 font-display text-sm font-bold uppercase tracking-wide transition-colors hover:bg-white hover:text-primary">View All Services</Link></div><div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">{services.map(({ icon: Icon, title, description }) => <Link key={title} to="/services" className="group border border-white/10 bg-white/5 p-8 transition-colors hover:bg-white/10"><Icon className="mb-6 h-8 w-8 text-accent transition-transform group-hover:scale-110" /><h3 className="mb-2 font-display text-lg font-bold uppercase tracking-wide">{title}</h3><p className="text-sm text-white/60">{description}</p></Link>)}</div></div></section>

    <section className="bg-white py-24"><div className="container px-6 md:px-12"><div className="flex flex-col items-center gap-16 lg:flex-row"><div className="w-full lg:w-1/2"><div className="relative aspect-square overflow-hidden bg-muted md:aspect-[4/3]"><div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1551698618-1dfe5d97d256?auto=format&fit=crop&q=80')] bg-cover bg-center" /><div className="absolute inset-0 bg-primary/20 mix-blend-multiply" /></div></div><div className="w-full lg:w-1/2"><h2 className="mb-6 font-display text-3xl font-bold leading-tight text-primary md:text-5xl">THE ATHLETE EXPERIENCE STARTS AT THE FINISH LINE</h2><p className="mb-6 text-lg leading-relaxed text-muted-foreground">Runners train for months for a single day. The moment they cross the finish line, they want exactly two things: their time, and their medal. We make sure the first one is flawless.</p><p className="mb-8 text-lg leading-relaxed text-muted-foreground">A timing failure isn't just an inconvenience; it ruins the race experience. That's why we build redundancy into every setup, from backup cameras to secondary chip systems. We don't leave accuracy to chance.</p><ul className="space-y-4">{["Primary and backup timing systems standard", "Battery backups for all critical infrastructure", "Finish line high-speed video verification", "Cellular and satellite data redundancies"].map((item) => <li key={item} className="flex items-center gap-3 font-medium"><Trophy className="h-5 w-5 shrink-0 text-accent" />{item}</li>)}</ul></div></div></div></section>

    <section className="relative overflow-hidden bg-secondary py-24 text-center"><div className="absolute right-0 top-0 h-full w-1/2 bg-[radial-gradient(ellipse_at_top_right,rgba(4,23,46,0.07),transparent_70%)]" /><div className="container relative z-10 px-6 md:px-12"><h2 className="mb-6 font-display text-4xl font-bold uppercase tracking-tight text-primary md:text-6xl">Ready for your next event?</h2><p className="mx-auto mb-10 max-w-2xl text-xl text-muted-foreground">Secure your date on our calendar. Let's discuss your race requirements and how we can elevate your finish line experience.</p><Link to="/contact" className="inline-flex h-16 items-center justify-center bg-primary px-12 font-display text-lg font-bold uppercase tracking-wide text-white transition-colors hover:bg-primary/90">Request a Proposal</Link></div></section>
  </SiteLayout>;
}
