import { Menu, Timer, X, MapPin, Phone, Mail } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Link, useLocation } from "react-router-dom";

const navItems = [
  { label: "Home", to: "/" },
  { label: "Services", to: "/services" },
  { label: "About Us", to: "/about" },
  { label: "Contact Us", to: "/contact" },
];

function Brand({ footer = false }: { footer?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-3 group" aria-label="Precision Timing Co. home">
      <Timer className="h-8 w-8 text-accent transition-transform group-hover:rotate-12" strokeWidth={2.4} />
      <span className="flex flex-col leading-none">
        <span className="font-display text-2xl font-bold tracking-tight">PRECISION</span>
        <span className={footer ? "mt-1 font-display text-sm font-bold tracking-[0.22em] text-white/65" : "mt-1 font-display text-sm font-bold tracking-[0.22em] text-muted-foreground"}>TIMING CO.</span>
      </span>
    </Link>
  );
}

export function SiteLayout({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  return (
    <div className="min-h-screen bg-white font-sans text-primary">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-primary/5 bg-white/95 py-5 backdrop-blur-md">
        <div className="container flex items-center justify-between px-6 md:px-12">
          <Brand />
          <nav className="hidden items-center gap-8 md:flex" aria-label="Main navigation">
            {navItems.map((item) => {
              const active = location.pathname === item.to;
              return (
                <Link key={item.to} to={item.to} className={`relative py-2 font-display text-sm font-bold uppercase tracking-wider transition-colors ${active ? "text-accent" : "text-primary hover:text-accent"}`}>
                  {item.label}
                  {active && <span className="absolute inset-x-0 -bottom-0.5 h-0.5 rounded-full bg-accent" />}
                </Link>
              );
            })}
          </nav>
          <Link to="/contact" className="hidden rounded-sm bg-primary px-6 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-white transition-colors hover:bg-accent md:block">Get a Quote</Link>
          <button type="button" onClick={() => setOpen(!open)} className="relative z-50 p-2 text-primary md:hidden" aria-label={open ? "Close menu" : "Open menu"}>
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </header>
      <div className={`fixed inset-0 z-40 flex flex-col items-center justify-center gap-7 bg-white transition-all duration-300 md:hidden ${open ? "visible opacity-100" : "invisible opacity-0"}`}>
        {navItems.map((item) => (
          <Link key={item.to} to={item.to} onClick={() => setOpen(false)} className={`font-display text-3xl font-bold uppercase tracking-wider ${location.pathname === item.to ? "text-accent" : "text-primary"}`}>{item.label}</Link>
        ))}
        <Link to="/contact" onClick={() => setOpen(false)} className="mt-2 w-64 rounded-sm bg-primary px-8 py-4 text-center font-display text-xl font-bold uppercase tracking-wider text-white">Get a Quote</Link>
      </div>
      <main className="pt-[88px] md:pt-[96px]">{children}</main>
      <footer className="bg-primary pt-16 text-white">
        <div className="container px-6 md:px-12">
          <div className="grid grid-cols-1 gap-12 pb-16 md:grid-cols-4">
            <div>
              <Brand footer />
              <p className="mt-6 max-w-xs text-sm leading-relaxed text-white/70">Professional race timing services for endurance events. We bring exactness to every finish line, so you can focus on the race.</p>
            </div>
            <FooterLinks title="Quick Links" links={navItems.map(({ label, to }) => ({ label: label === "Services" ? "Timing Services" : label, to }))} />
            <FooterLinks title="Services" links={[{ label: "RFID Chip Timing", to: "/services" }, { label: "Live Online Results", to: "/services" }, { label: "Race Clock Rentals", to: "/services" }, { label: "Custom Bib Printing", to: "/services" }, { label: "Finish Line Setup", to: "/services" }]} />
            <div>
              <h4 className="font-display text-lg font-bold uppercase tracking-wider">Contact Info</h4>
              <ul className="mt-6 space-y-4 text-sm text-white/70">
                <li className="flex items-start gap-3"><MapPin className="mt-0.5 h-5 w-5 shrink-0 text-accent" /><span>123 Timing Way, Suite 400<br />Denver, CO 80202</span></li>
                <li className="flex items-center gap-3"><Phone className="h-5 w-5 shrink-0 text-accent" />(555) 123-4567</li>
                <li className="flex items-center gap-3"><Mail className="h-5 w-5 shrink-0 text-accent" />hello@precisiontiming.com</li>
              </ul>
            </div>
          </div>
          <div className="flex flex-col items-center justify-between gap-4 border-t border-white/10 py-8 text-sm text-white/50 md:flex-row">
            <p>© 2026 Precision Timing Co. All rights reserved.</p>
            <div className="flex gap-5"><span>Privacy Policy</span><span>Terms of Service</span></div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function FooterLinks({ title, links }: { title: string; links: { label: string; to: string }[] }) {
  return <div><h4 className="font-display text-lg font-bold uppercase tracking-wider">{title}</h4><ul className="mt-6 space-y-4">{links.map((link) => <li key={link.label}><Link to={link.to} className="text-sm font-medium text-white/70 transition-colors hover:text-white">{link.label}</Link></li>)}</ul></div>;
}
